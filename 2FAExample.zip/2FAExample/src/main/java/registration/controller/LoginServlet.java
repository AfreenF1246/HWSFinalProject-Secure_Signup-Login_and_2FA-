package registration.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import  registration.model.LoginBean;
import registration.dao.*;

import org.mindrot.jbcrypt.BCrypt; 

import registration.model.TimeBasedOnetimePassword;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private LoginDao loginDao;
	
	public void init() {
		loginDao = new LoginDao();
	}
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
        String password = request.getParameter("password");
        LoginBean loginBean = new LoginBean();
        
        //String orig = BCrypt.checkpw(password, //i need the password from the SQL table); 
        loginBean.setUsername(username);
        loginBean.setPassword(password);
        
        

        try {
            if (loginDao.validate(loginBean)) {
                //HttpSession session = request.getSession();
                // session.setAttribute("username",username);
            	String originalSecretKey = "IForgotMyPassword"; //this key would be created with a unique external device 
                // Add your TOTP verification logic here
                String encodedSecretKey = TimeBasedOnetimePassword.encodeBase32(originalSecretKey);
                String freshTOTP = TimeBasedOnetimePassword.generateTOTP(encodedSecretKey);
                System.out.println("Generated TOTP: " + freshTOTP);
                //boolean isValid = TimeBasedOnetimePassword.validateTOTP(encodedSecretKey, freshTOTP);
                //HttpSession session = request.getSession(true);
                request.setAttribute("encodedSecretKey", encodedSecretKey);
                request.setAttribute("freshTOTP", freshTOTP);
                request.getRequestDispatcher("2factorAuthPage.jsp").forward(request, response);
                //response.sendRedirect("");
                	
                
                
            } else {
                //session.setAttribute("user", username);
                response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

