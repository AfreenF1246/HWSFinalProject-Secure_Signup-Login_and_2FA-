package registration.controller;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import registration.controller.LoginServlet;
import registration.model.LoginBean;
import registration.model.TimeBasedOnetimePassword;

/**
 * Servlet implementation class TOTPServlet
 */
@WebServlet("/TOTPServlet")
public class TOTPServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TOTPServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String userInputTOTP = request.getParameter("totp");
		//String encodedSecretKey = (String) request.getAttribute("encodedSecretKey");
		//String encodedSecretKey = (String) request.getSession().getAttribute("encodedSecretKey");
        //String storedTOTP = (String) request.getSession().getAttribute("freshTOTP");
        String freshTOTP = request.getParameter("ftotp");
        System.out.println("Value of freshTOTP: " + freshTOTP);

        
		if (freshTOTP != null && userInputTOTP != null) {
            // Validate the user-entered TOTP against the one generated using the secret key
			//boolean isValidTOTP = TimeBasedOnetimePassword.validateTOTP(freshTOTP, userInputTOTP);
            //System.out.println("check if valid: " + isValidTOTP);

            if (freshTOTP.equals(userInputTOTP)) {
                // TOTP is valid, perform further actions (e.g., grant access)
                response.sendRedirect("loginsuccess.jsp");
            } else {
                // TOTP is not valid, redirect back to the login page with an error message
                response.sendRedirect("error.jsp");
            }
        } else {
            // Either the secret key or the user-entered TOTP is null, handle the error accordingly
            response.sendRedirect("error.jsp");
        }      
     
        
		doGet(request, response);
	}

}
