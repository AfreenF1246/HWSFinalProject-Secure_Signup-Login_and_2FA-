package registration.dao;
import  registration.model.LoginBean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.mindrot.jbcrypt.BCrypt;

public class LoginDao {

	public boolean validate(LoginBean loginBean) throws ClassNotFoundException {
        boolean status = false;

        Class.forName("com.mysql.jdbc.Driver");

        try (Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3306/HWSProject", "root", "password");

        		PreparedStatement preparedStatement = connection
                        .prepareStatement("select password from 2FA.users where username = ?")) {

               preparedStatement.setString(1, loginBean.getUsername());

               ResultSet rs = preparedStatement.executeQuery();

               if (rs.next()) {
                   String hashedPasswordFromDatabase = rs.getString("password");

                   // Hash the password entered during login
                   String enteredPassword = loginBean.getPassword();
                   
                   status = BCrypt.checkpw(enteredPassword, hashedPasswordFromDatabase);
                   
               }
               
        } catch (SQLException e) {
            // process exception
            printSQLException(e);
        }
        return status;
        
	}
        
        private void printSQLException(SQLException ex) {
            for (Throwable e: ex) {
                if (e instanceof SQLException) {
                    e.printStackTrace(System.err);
                    System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                    System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                    System.err.println("Message: " + e.getMessage());
                    Throwable t = ex.getCause();
                    while (t != null) {
                        System.out.println("Cause: " + t);
                        t = t.getCause();
                    }
                }
            }
        }
    }


